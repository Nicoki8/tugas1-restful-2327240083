// Impor express
const express = require("express");
const app = express() ; getSelection_

// Middleware untuk membaca JSON dari body request
app.use(express.json()); getComputedStyle

// Data awal (minimal 3 data) dan variabel nextId untuk Topik Salon
let nextId = 4;
let salonServices = [
  {
    id: 1,
    namaLayanan: "Creambath",
    kategori: "rambut",
    durasiMenit: 60,
    harga: 85000,
    tersedia: true
  },
  {
    id: 2,
    namaLayanan: "Facial Mask",
    kategori: "wajah",
    durasiMenit: 45,
    harga: 100000,
    tersedia: true
  },
  {
    id: 3,
    namaLayanan: "Manicure",
    kategori: "kuku",
    durasiMenit: 30,
    harga: 50000,
    tersedia: false
  }
];

// GET / - Info API
app.get("/", (req, res) => {
  res.json({
    nama: "Nico Ramadhan Wijaya",
    nim: "2327240083",
    topik: "Salon",
    nomorTopik: 4,
    endpoints: [
      "GET /salon-services",
      "GET /salon-services/:id",
      "GET /salon-services?kategori=rambut",
      "POST /salon-services",
      "PUT /salon-services/:id",
      "DELETE /salon-services/:id"
    ]
  });
});

// GET /salon-services - Ambil semua data atau filter dengan query string (?kategori=...)
app.get("/salon-services", (req, res) => {
  const { kategori } = req.query;
  if (kategori) {
    const filtered = salonServices.filter(s => s.kategori.toLowerCase() === kategori.toLowerCase());
    return res.json(filtered);
  }
  res.json(salonServices);
});

// GET /salon-services/:id - Ambil satu data berdasarkan ID
app.get("/salon-services/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const service = salonServices.find(s => s.id === id);
  if (!service) {
    return res.status(404).json({
      status: "error",
      message: `Data dengan id ${id} tidak ditemukan`,
      data: null
    });
  }
  res.json(service);
});

// POST /salon-services - Tambah data baru
app.post("/salon-services", (req, res) => {
  const { namaLayanan, kategori, durasiMenit, harga, tersedia } = req.body;

  // Validasi field wajib (*)
  if (!namaLayanan || !kategori || durasiMenit === undefined || harga === undefined || tersedia === undefined) {
    return res.status(400).json({
      status: "error",
      message: "Semua field wajib diisi (namaLayanan, kategori, durasiMenit, harga, tersedia)",
      data: null
    });
  }

  const newService = {
    id: nextId++,
    namaLayanan,
    kategori,
    durasiMenit,
    harga,
    tersedia
  };

  salonServices.push(newService);
  res.status(201).json({
    status: "success",
    message: "Data berhasil ditambahkan",
    data: newService
  });
});

// PUT /salon-services/:id - Ubah seluruh data
app.put("/salon-services/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const index = salonServices.findIndex(s => s.id === id);

  if (index === -1) {
    return res.status(404).json({
      status: "error",
      message: `Data dengan id ${id} tidak ditemukan`,
      data: null
    });
  }

  const { namaLayanan, kategori, durasiMenit, harga, tersedia } = req.body;

  if (!namaLayanan || !kategori || durasiMenit === undefined || harga === undefined || tersedia === undefined) {
    return res.status(400).json({
      status: "error",
      message: "Semua field wajib diisi untuk penggantian penuh",
      data: null
    });
  }

  salonServices[index] = {
    id,
    namaLayanan,
    kategori,
    durasiMenit,
    harga,
    tersedia
  };

  res.status(200).json({
    status: "success",
    message: "Data berhasil diubah",
    data: salonServices[index]
  });
});

// DELETE /salon-services/:id - Hapus data
app.delete("/salon-services/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const index = salonServices.findIndex(s => s.id === id);

  if (index === -1) {
    return res.status(404).json({
      status: "error",
      message: `Data dengan id ${id} tidak ditemukan`,
      data: null
    });
  }

  salonServices.splice(index, 1);
  res.status(200).json({
    status: "success",
    message: `Data salon dengan id ${id} berhasil dihapus`,
    data: null
  });
});

// Middleware catch-all 404 untuk endpoint tidak terdaftar
app.use((req, res) => {
  res.status(404).json({
    status: "error",
    message: "Endpoint tidak ditemukan",
    data: null
  });
});

// Konfigurasi server lokal dan ekspor untuk Vercel
const PORT = process.env.PORT || 3000;
if (process.env.NODE_ENV !== 'production') {
  app.listen(PORT, () => console.log(`Server berjalan di http://localhost:${PORT}`));
}

module.exports = app;